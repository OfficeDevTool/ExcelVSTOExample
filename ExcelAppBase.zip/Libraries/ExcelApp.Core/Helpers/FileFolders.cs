﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;

namespace ExcelApp.Core.Helpers
{
    public static class FileFolders
    {

        public static void OpenFile(string filePath)
        {
            try
            {
                if (filePath == string.Empty)
                    return;
                var attributes = File.GetAttributes(filePath);
                File.SetAttributes(filePath, attributes | FileAttributes.ReadOnly);
                System.Diagnostics.Process.Start(filePath);

            }
            catch (System.ComponentModel.Win32Exception)
            {
                MessageBox.Show("No application is associated with this file type." + Environment.NewLine + Environment.NewLine + filePath, "No action taken.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;

            }
            //catch (Exception ex)
            //{
            //  ErrorHandler.DisplayMessage(ex);
            //}
        }
    }
}
