﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using ExcelApp.Core.Helpers;


namespace ExcelApp.Core
{
    public class ErrorHandler
    {
        public static void DisplayMessage(Exception ex, Boolean isSilent = false)
        {
            var sf = new System.Diagnostics.StackFrame(1);
            var caller = sf.GetMethod();
            var errorDescription = ex.ToString().Replace("\r\n", " ");
            var currentProcedure = caller.Name.Trim();
            var currentFileName = AssemblyInfo.GetCurrentFileName();

            var logMessage = string.Concat(new Dictionary<string, string>
            {
                ["PROCEDURE"] = currentProcedure,
                ["DESCRIPTION"] = errorDescription,
                ["FILE NAME"] = currentFileName,
                ["MACHINE NAME"] = Environment.MachineName,
                ["USER NAME"] = Environment.UserName,
            }.Select(x => $"[{x.Key}]=|{x.Value}|"));

            //log.Error(logMessage);

            var userMessage = new StringBuilder()
                .AppendLine("Contact your system administrator. A record has been created in the log file.")
                .AppendLine("Procedure: " + currentProcedure)
                .AppendLine("Description: " + errorDescription)
                .ToString();

            if (isSilent == false)
            {
                MessageBox.Show(userMessage, @"Unexpected Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}