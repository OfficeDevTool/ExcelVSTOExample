﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using ExcelApp.Core;
using Microsoft.Office.Tools.Excel.Extensions;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;

namespace ExcelTemplateBase
{
    public partial class StartSheet
    {
        #region VSTO Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.RefreshLogButton.Click += new System.EventHandler(this.RefreshLogButton_Click);
            this.Startup += new System.EventHandler(this.StartSheet_Startup);
            this.Shutdown += new System.EventHandler(this.StartSheet_Shutdown);

        }

        #endregion

        private Excel.Worksheet _worksheet = Globals.ThisWorkbook.ThisApplication.ActiveSheet.GetVstoObject(Globals.Factory);
        //private AssemblyInfo _assemblyInfo = AssemblyInfo();

        private void StartSheet_Startup(object sender, EventArgs e)
        {
            this.ProjectName.Value2 = AssemblyInfo.Title;
            this.ApplicationName.Value2 = AssemblyInfo.Description;
        }

        private void StartSheet_Shutdown(object sender, EventArgs e)
        {

        }


        private void RefreshLogButton_Click(object sender, EventArgs e)
        {

        }

    }
}
